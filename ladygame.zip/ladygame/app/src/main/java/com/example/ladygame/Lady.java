package com.example.ladygame;

public class Lady {

}
